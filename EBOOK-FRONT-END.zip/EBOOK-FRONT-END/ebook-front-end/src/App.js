import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Login from './components/Login';
import Registration from './components/Registration';
//import Header from './components/Header';
import BookDisplay from './components/users/BookDisplay';
import Cart from './components/users/Cart';
import Orders from './components/users/Orders';
import Profile from './components/users/Profile';

function App() {
  return (
    <Router>
      <div className="container mt-3">
        {/* Navigation Links */}
        <nav>
          <Link to="/login" className="btn btn-primary me-2">Login</Link>
          <Link to="/register" className="btn btn-secondary me-2">Register</Link>
          <Link to="/books" className="btn btn-success me-2">Books</Link>
          <Link to="/cart" className="btn btn-warning me-2">Cart</Link>
          <Link to="/orders" className="btn btn-info me-2">Orders</Link>
          <Link to="/profile" className="btn btn-dark">Profile</Link>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/books" element={<BookDisplay />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/" element={<Login />} /> {/* Default route */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;