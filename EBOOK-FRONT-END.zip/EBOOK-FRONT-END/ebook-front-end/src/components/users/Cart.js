import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import { baseUrl } from "../constants";
import Header from "./Header";

export default function Cart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {
    const data = {
      Email: localStorage.getItem("username"),
    };
    const url = `${baseUrl}/api/Admin/cartList`;
    axios
      .post(url, data)
      .then((result) => {
        const data = result.data;
        if (data.statusCode === 200) {
          setData(data.listCart);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handlePlaceOrder = (e) => {
    e.preventDefault();
    const data = {
      Email: localStorage.getItem("username"),
    };
    const url = `${baseUrl}/api/Books/placeOrder`;
    axios
      .post(url, data)
      .then((result) => {
        const dt = result.data;
        if (dt.statusCode === 200) {
          setData([]);
          alert(dt.statusMessage);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Fragment>
      <Header />
      <br />
      <div className="form-group col-md-12">
        <h3>Cart Items</h3>
        {data && data.length > 0 ? (
          <button className="btn btn-primary" onClick={(e) => handlePlaceOrder(e)}>
            Place Order
          </button>
        ) : (
          <p>No items in the cart.</p>
        )}
      </div>
      <div
        style={{
          backgroundColor: "white",
          width: "86%",
          margin: "0 auto",
          borderRadius: "10px",
        }}
      >
        <div className="card-deck">
          {data && data.length > 0 ? (
            data.map((val, index) => (
              <div key={index} className="col-md-3" style={{ marginBottom: "21px" }}>
                <div className="card">
                  <img
                    className="card-img-top"
                    src={`assets/images/${val.imageUrl}`}
                    alt={val.bookName} // Fix redundant alt attribute
                  />
                  <div className="card-body">
                    <h4 className="card-title">Name: {val.bookName}</h4>
                    <h4 className="card-title">Quantity: {val.quantity}</h4>
                    <button className="btn btn-danger">Remove</button> {/* Replace <a> with <button> */}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p>No items to display. Kindly add books to your cart.</p>
          )}
        </div>
      </div>
    </Fragment>
  );
}