import React, { useState, Fragment, useEffect } from "react";
import { Link } from "react-router-dom";

export default function Header() {
  const [username, setUserName] = useState("");

  useEffect(() => {
    setUserName(localStorage.getItem("username"));
  }, []);

  const logout = (e) => {
    e.preventDefault();
    localStorage.removeItem("username");
    window.location.href = "/";
  };

  return (
    <Fragment>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <button className="navbar-brand" style={{ background: "none", border: "none" }}>
          E-Books (User Panel)
        </button>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/cart">
                Cart
              </Link>
            </li>
            <li className="nav-item">
              <span className="nav-link">Welcome, {username}</span>
            </li>
            <li className="nav-item">
              <button className="btn btn-danger" onClick={logout}>
                Logout
              </button>
            </li>
          </ul>
        </div>
      </nav>
    </Fragment>
  );
}