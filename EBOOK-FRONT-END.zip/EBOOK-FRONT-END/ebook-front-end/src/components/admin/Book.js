import React, { Fragment, useEffect, useState } from "react";
import axios from "axios";
import AdminHeader from "./AdminHeader";
import { baseUrl } from "./constants";

export default function Book() {
    const [data, setData] = useState([]);
    const [bookId, setBookId] = useState("");
    const [title, setTitle] = useState("");
    const [author, setAuthor] = useState("");
    const [price, setPrice] = useState("");
    const [discount, setDiscount] = useState("");
    const [quantity, setQuantity] = useState("");
    const [publicationDate, setPublicationDate] = useState("");
    const [file, setFile] = useState("");
    const [fileName, setFileName] = useState("");
    const [addUpdateFlag, setAddUpdateFlag] = useState(true);

    useEffect(() => {
        getData();
    }, []);

    const getData = () => {
        const data = {
            type: "Get",
            Email: localStorage.getItem("loggedEmail"),
        };
        const url = `${baseUrl}/api/Admin/addUpdateBook`;
        axios
            .post(url, data)
            .then((result) => {
                const data = result.data;
                if (data.statusCode === 200) {
                    setData(data.listBooks);
                }
            })
            .catch((error) => {
                console.log(error);
            });
    };

    const deleteBook = (e, id) => {
        e.preventDefault();
        const data = {
            Id: id,
            Type: "Delete",
        };
        const url = `${baseUrl}/api/Admin/addUpdateBook`;
        axios
            .post(url, data)
            .then((result) => {
                const data = result.data;
                if (data.statusCode === 200) {
                    getData();
                    alert(data.statusMessage);
                }
            })
            .catch((error) => {
                console.log(error);
            });
    };

    const editBook = (e, id) => {
        e.preventDefault();
        setAddUpdateFlag(false);
        const data = {
            ID: id,
            Type: "GetByID",
        };
        const url = `${baseUrl}/api/Admin/addUpdateBook`;
        axios
            .post(url, data)
            .then((result) => {
                const data = result.data;
                if (data.statusCode === 200) {
                    setBookId(id);
                    setTitle(data.listBooks[0]['title']);
                    setAuthor(data.listBooks[0]['author']);
                    setPrice(data.listBooks[0]['price']);
                    setDiscount(data.listBooks[0]['discount']);
                    setQuantity(data.listBooks[0]['quantity']);
                    setPublicationDate(data.listBooks[0]['publicationDate']);
                }
            })
            .catch((error) => {
                console.log(error);
            });
    };

    const uploadFile = async (e) => {
        e.preventDefault();
        const formdata = new FormData();
        formdata.append("FormFile", file);
        formdata.append("FileName", fileName);
        // Add file upload logic here
    };

    const Clear = () => {
        setTitle("");
        setAuthor("");
        setPrice("");
        setDiscount("");
        setPublicationDate("");
        setFile("");
        setFileName("");
        setQuantity("");
    };

    const updateBook = (e) => {
        const data = {
            ID: bookId,
            Title: title,
            Author: author,
            Price: price,
            Discount: discount,
            Quantity: quantity,
            PublicationDate: publicationDate,
        };
        // Add update logic here
    };

    return (
        <Fragment>
            <AdminHeader />
            <br></br>
            <div className="form-group col-md-12">
                <h3>Book List</h3>
            </div>
            {data ? (
                <table
                    className="table stripped table-hover mt-4"
                    style={{ backgroundColor: "white", width: "88%", margin: "0 auto" }}
                >
                    <thead className="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Author</th>
                            <th scope="col">Price</th>
                            <th scope="col">Discount</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Publication Date</th>
                            <th scope="col">Manage</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((val, index) => {
                            return (
                                <tr key={index}>
                                    <th scope="row">{index + 1}</th>
                                    <td>{val.title}</td>
                                    <td>{val.author}</td>
                                    <td>{val.price}</td>
                                    <td>{val.discount}</td>
                                    <td>{val.quantity}</td>
                                    <td>{val.publicationDate}</td>
                                    <td>
                                        <Button
                                            variant="secondary"
                                            onClick={() => editBook(val.id)}
                                        >
                                            Edit
                                        </Button>
                                        <Button
                                            variant="danger"
                                            onClick={(e) => deleteBook(e, val.id)}
                                        >
                                            Delete
                                        </Button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            ) : (
                "No data found"
            )}
        </Fragment>
    );
}