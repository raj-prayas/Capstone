import React, { Fragment, useState } from "react";
import { Link, useNavigate } from "react-router-dom"; // Import useNavigate
import { baseUrl } from "./constants";
import axios from "axios";

export default function Registration() {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate(); // Initialize useNavigate

    const handleSave = (e) => {
        let error = "";
        if (firstName === "") error = error + "FirstName ;";
        if (lastName === "") error = error + "LastName ;";
        if (email === "") error = error + "Email ;";
        if (password === "") error = error + "Password ;";

        if (error.length > 0) {
            error = error.substring(0, error.length - 1) + " cannot be blank";
            alert(error);
            return;
        }

        e.preventDefault();
        const url = `${baseUrl}/api/Users/registration`;
        const data = {
            FirstName: firstName,
            LastName: lastName,
            Email: email,
            Password: password,
        };

        axios
            .post(url, data)
            .then((result) => {
                clear();
                const dt = result.data;
                alert(dt.statusMessage);
                if (dt.statusCode === 200) { // Check if registration was successful
                    navigate("/"); // Redirect to login page
                }
            })
            .catch((error) => {
                console.log(error);
            });
    };

    const clear = () => {
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
    };

    return (
        <Fragment>
            <div
                style={{
                    backgroundColor: "white",
                    width: "80%",
                    margin: "0 auto",
                    borderRadius: "10px",
                }}
            >
                <div className="mt-4" style={{ margin: "0 auto", width: "436px" }}>
                    <h3>E-Books Registration</h3>
                </div>
                <section
                    className="vh-100"
                    style={{ backgroundColor: "#eee", padding: "7px" }}
                >
                    <div className="container h-100">
                        <div className="row d-flex justify-content-center align-items-center h-100">
                            <div className="col-lg-12 col-xl-11">
                                <div
                                    className="card text-black"
                                    style={{ borderRadius: "25px" }}
                                >
                                    <div className="card-body p-md-5">
                                        <div className="row justify-content-center">
                                            <div className="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">
                                                <form className="mx-1 mx-md-4">
                                                    <div className="d-flex flex-row align-items-center mb-4">
                                                        <i className="fas fa-user fa-lg me-3 fa-fw"></i>
                                                        <div className="form-outline flex-fill mb-8">
                                                            <input
                                                                type="text"
                                                                id="form3Example1c"
                                                                className="form-control"
                                                                onChange={(e) =>
                                                                    setFirstName(e.target.value)
                                                                }
                                                                value={firstName}
                                                                placeholder="Enter First Name"
                                                            />
                                                        </div>
                                                    </div>

                                                    <div className="d-flex flex-row align-items-center mb-4">
                                                        <i className="fas fa-user fa-lg me-3 fa-fw"></i>
                                                        <div className="form-outline flex-fill mb-8">
                                                            <input
                                                                type="text"
                                                                id="form3Example1c"
                                                                className="form-control"
                                                                onChange={(e) =>
                                                                    setLastName(e.target.value)
                                                                }
                                                                value={lastName}
                                                                placeholder="Enter Last Name"
                                                            />
                                                        </div>
                                                    </div>

                                                    <div className="d-flex flex-row align-items-center mb-4">
                                                        <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                                        <div className="form-outline flex-fill mb-8">
                                                            <input
                                                                type="email"
                                                                id="form3Example3c"
                                                                className="form-control"
                                                                onChange={(e) =>
                                                                    setEmail(e.target.value)
                                                                }
                                                                value={email}
                                                                placeholder="Enter Email"
                                                            />
                                                        </div>
                                                    </div>

                                                    <div className="d-flex flex-row align-items-center mb-4">
                                                        <i className="fas fa-lock fa-lg me-3 fa-fw"></i>
                                                        <div className="form-outline flex-fill mb-8">
                                                            <input
                                                                type="password"
                                                                id="form3Example4c"
                                                                className="form-control"
                                                                onChange={(e) =>
                                                                    setPassword(e.target.value)
                                                                }
                                                                value={password}
                                                                placeholder="Enter Password"
                                                            />
                                                        </div>
                                                    </div>

                                                    <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                                                        <button
                                                            type="button"
                                                            className="btn btn-primary btn-lg"
                                                            onClick={(e) => handleSave(e)}
                                                        >
                                                            Register
                                                        </button>
                                                        &nbsp;
                                                        <Link
                                                            to="/"
                                                            className="btn btn-info btn-lg btn-block"
                                                        >
                                                            Login
                                                        </Link>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    );
}