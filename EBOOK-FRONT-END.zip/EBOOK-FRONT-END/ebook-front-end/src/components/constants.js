// constants.js

// Base URL for the API
export const baseUrl = "http://localhost:5000";

// API Endpoints
export const apiEndpoints = {
    // User-related endpoints
    viewUser: `${baseUrl}/api/Users/viewUser`,
    updateProfile: `${baseUrl}/api/Users/updateProfile`,
    login: `${baseUrl}/api/Users/login`,
    register: `${baseUrl}/api/Users/register`,

    // Book-related endpoints
    bookList: `${baseUrl}/api/Books/bookList`,
    addUpdateBook: `${baseUrl}/api/Books/addUpdateBook`,
    deleteBook: `${baseUrl}/api/Books/deleteBook`,

    // Cart-related endpoints
    addToCart: `${baseUrl}/api/Books/addToCart`,
    cartList: `${baseUrl}/api/Books/cartList`,
    placeOrder: `${baseUrl}/api/Books/placeOrder`,

    // Order-related endpoints
    orderList: `${baseUrl}/api/Books/orderList`,
    orderDetails: `${baseUrl}/api/Books/orderDetails`,

    // Other endpoints (if needed)
    uploadFile: `${baseUrl}/api/Books/uploadFile`,
};

// Other constants (if needed)
export const appName = "E-Books";
export const maxQuantity = 10; // Maximum quantity of books a user can add to the cart
export const defaultProfileImage = "assets/images/default-profile.png"; // Default profile image path