import axios from "axios";

const baseUrl = "http://localhost:5000";

// User-related APIs
export const loginUser = async (email, password) => {
  const url = `${baseUrl}/api/Users/login`;
  return await axios.post(url, { Email: email, Password: password });
};

export const registerUser = async (userData) => {
  const url = `${baseUrl}/api/Users/register`;
  return await axios.post(url, userData);
};

export const getUserProfile = async () => {
  const url = `${baseUrl}/api/Users/viewUser`;
  return await axios.post(url, { Email: localStorage.getItem("username") });
};

// Book-related APIs
export const getBookList = async () => {
  const url = `${baseUrl}/api/Books/bookList`;
  return await axios.post(url, { Email: "Admin" });
};

export const addUpdateBook = async (bookData) => {
  const url = `${baseUrl}/api/Books/addUpdateBook`;
  return await axios.post(url, bookData);
};

export const deleteBook = async (id) => {
  const url = `${baseUrl}/api/Books/deleteBook`;
  return await axios.post(url, { ID: id, Type: "Delete" });
};

// Cart-related APIs
export const addToCart = async (bookId, quantity) => {
  const url = `${baseUrl}/api/Books/addToCart`;
  return await axios.post(url, {
    ID: bookId,
    Quantity: quantity,
    Email: localStorage.getItem("username"),
  });
};

export const getCartList = async () => {
  const url = `${baseUrl}/api/Books/cartList`;
  return await axios.post(url, { Email: localStorage.getItem("username") });
};

export const placeOrder = async () => {
  const url = `${baseUrl}/api/Books/placeOrder`;
  return await axios.post(url, { Email: localStorage.getItem("username") });
};

// Order-related APIs
export const getOrderList = async (type, id) => {
  const url = `${baseUrl}/api/Books/orderList`;
  return await axios.post(url, { ID: id, type, Email: localStorage.getItem("username") });
};

export const updateOrderStatus = async (orderNo, orderStatus) => {
  const url = `${baseUrl}/api/Admin/updatedOrderStatus`;
  return await axios.post(url, { OrderNo: orderNo, OrderStatus: orderStatus });
};